package com.myportfolio.portfolioms.dto;

import java.util.List;

public record MutualFundInputList(List<Integer> ids) {
}
