package com.myportfolio.mutulfundsms.dto;

import java.util.List;

public record MutualFundInputList(List<Integer> ids) {
}
