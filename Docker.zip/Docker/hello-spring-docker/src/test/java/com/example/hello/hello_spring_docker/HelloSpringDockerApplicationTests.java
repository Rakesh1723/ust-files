package com.example.hello.hello_spring_docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
