package com.example.hello.hello_spring_docker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloSpringDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloSpringDockerApplication.class, args);
	}

}
