## Steps to follow

## Fork and clone this repository

## Implement all the methods in the `ShoppingCartService` class

## Run the tests

## Implement the `ShoppingCartRepository` class

## Run the tests

## Commit and push your code to your repository

## Give me the reporter access to your repository

## Good luck!
