package com.shoppingcart.app.exception;

public class InvalidProductException extends Exception {
    public InvalidProductException(String message) {
        super(message);
    }
}
