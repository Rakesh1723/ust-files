package com.shoppingcart.app;


import com.shoppingcart.app.configuration.ShoppingCartConfig;
import com.shoppingcart.app.exception.InvalidProductException;
import com.shoppingcart.app.exception.InvalidQuantityException;
import com.shoppingcart.app.model.Product;
import com.shoppingcart.app.service.ShoppingCartService;
import com.shoppingcart.app.service.ShoppingCartServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {

        ApplicationContext context=new AnnotationConfigApplicationContext(ShoppingCartConfig.class);
        ShoppingCartService service=context.getBean(ShoppingCartServiceImpl.class);
        try {
            service.addProduct(new Product(1,"iphone16","electronics",70000,1),4);
            service.addProduct(new Product(2,"realmec3","electronics",20000,1),2);
        }catch (InvalidProductException | InvalidQuantityException e) {
            throw new RuntimeException(e);
        }
        service.displayCartItems();
        System.out.println(service.findMostExpensiveProduct());
    }
}