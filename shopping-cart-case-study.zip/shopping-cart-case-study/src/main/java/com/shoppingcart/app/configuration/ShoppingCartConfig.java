package com.shoppingcart.app.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.shoppingcart.app")
public class ShoppingCartConfig {
}
