package com.shoppingcart.app.repository;

import com.shoppingcart.app.exception.InvalidQuantityException;
import com.shoppingcart.app.exception.ProductNotFoundException;
import com.shoppingcart.app.model.Product;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class ShoppingCartRepositoryImpl implements ShoppingCartRepository , InitializingBean {


    private List<Product> products;

//    public ShoppingCartRepositoryImpl() {
//
//    }

    public void addProduct(Product product, int quantity) throws InvalidQuantityException {
        if(quantity<=0)
            throw new InvalidQuantityException("Invalid Quantity exception");
        product.setQuantity(quantity);
          products.add(product);
    }

    public void removeProduct(Product product) throws ProductNotFoundException {

         if(!products.stream().anyMatch(i->i.equals(product)))
             throw new ProductNotFoundException("Product not found exception");

           products.remove(product);
    }

    public void updateProductQuantity(Product product, int quantity) throws ProductNotFoundException, InvalidQuantityException {

        if(quantity<=0)
            throw new InvalidQuantityException("Invalid Quantity exception");

        if(!products.stream().anyMatch(i->i.equals(product)))
            throw new ProductNotFoundException("Product not found exception");

        products.stream()
                .filter(i -> i.equals(product))
                .forEach(i -> i.setQuantity(quantity));
    }

    public double calculateTotalPrice() {
        return products.stream().mapToDouble(i->i.getPrice()*i.getQuantity()).sum();
    }

    public List<Product> filterProductsByCategory(String category) {
        return products.stream().filter(i->i.getCategory().equals(category)).toList();
    }

    public List<Product> filterProductsByPriceRange(double minPrice, double maxPrice) {
        return products.stream().filter(i->i.getPrice()>=minPrice && i.getPrice()<=maxPrice).toList();
    }


    // Output Format:
    //Product1 2 10.0
    //Product2 3 20.0
    public void displayCartItems() {
        int i=1;
        for(Product p:products)
             System.out.print("Product"+i+++" "+p.getQuantity()+" "+p.getPrice()+"\n");
    }

    public Optional<Product> findMostExpensiveProduct() {
        return products.stream().sorted((a,b)->Double.compare(b.getPrice(),a.getPrice())).findFirst();
    }

    public List<Product> sortProductsByName() {
        return products.stream().sorted((a,b)->a.getName().compareTo(b.getName())).toList() ;
    }

    public double calculateDiscountedTotal(double discountPercentage) {
        return products.stream().mapToDouble(i->(i.getPrice()-(i.getPrice()*(discountPercentage/100)))*i.getQuantity()).sum();
    }

    public List<Product> getProducts() {
        return products;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        products=new ArrayList<>();

    }
}
