package com.stackroute.generic;

import java.util.function.Predicate;
import java.util.List;
import java.util.Optional;

public class BookTitleSearcher {

    public Optional<List<String>> getBookList(List<String>  bookList, String str){
       if(str==null||str.trim().isEmpty()||bookList==null)
        return Optional.empty();
       var al= bookList.stream().filter(i->i.contains(str)).toList();
         if(al.isEmpty())
             return Optional.empty();
         return Optional.of(al);

    }

    public Optional<List<String>> searchBookNames(List<String>  bookList,Predicate<String> str){
        if(str==null||str.toString().isEmpty()||bookList==null|| bookList.isEmpty())
            return Optional.empty();

        return Optional.of(bookList.stream().filter(str).toList());
    }
}
