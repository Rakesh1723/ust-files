package com.stackroute.lamdbaexpression;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ConsumerFunctionalInterface {
    //write logic to find the square of each number in a given list of numbers
    public List<BigInteger> findSquare(List<BigInteger> list) {
        List<BigInteger> al=new ArrayList<>();
        if(list.isEmpty())
            return al;
         return list.stream().map(i->i.multiply(i)).toList();
    }
}
