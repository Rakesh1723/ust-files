package com.stackroute.exercises;


public class Fraction {
    //Write logic to calculate the fraction and return as a String
    public String fractionCalculator(int firstNumber, int secondNumber) {
        try { if(secondNumber==0)
                throw new ArithmeticException("java.lang.ArithmeticException: / by zero");
            return String.valueOf(firstNumber / secondNumber);
        }
        catch(ArithmeticException ex)
        {
            return ex.getMessage();
        }

    }
}
