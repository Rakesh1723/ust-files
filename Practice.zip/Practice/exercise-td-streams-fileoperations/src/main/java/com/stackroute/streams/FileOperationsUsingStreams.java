package com.stackroute.streams;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class FileOperationsUsingStreams {

    public static int getUniqueWordCount(String str)
    {
        if(str.trim().isEmpty())
            return 0;

//          Set<String> res=new HashSet<String>();
//        try {
//              ArrayList<String> al=new ArrayList<>();
//              Files.lines(Paths.get(str)).forEach(i->al.add(i));
//            for(String i:al)
//            {
//                String[] arr=i.split(" ");
//                for(String s:arr) {
//                    res.add(s);
//                }
//            }
//        } catch (IOException ex) {
//             ex.getMessage();
//        }
//        return res.size();

        try{
           return (int) Files.lines(Paths.get(str)).flatMap(i -> Arrays.stream(i.split("\\W"))).distinct().count();

        }catch(IOException ex){
            ex.getMessage();
       }
        return 0;
    }

    public Set<String> getWordListWithoutDuplicates(String str){
        Set<String> res=new HashSet<String>();
        if(str.trim().isEmpty())
            return res;
//        try {
//            ArrayList<String> al=new ArrayList<>();
//            Files.lines(Paths.get(str)).forEach(i->al.add(i));
//            for(String i:al)
//            {
//                String arr[]=i.split(" ");
//                for(String s:arr) {
//                    res.add(s);
//                }
//            }
//        } catch (IOException ex) {
//            ex.getMessage();
//        }

         try {
             return Files.lines(Paths.get(str)).flatMap(i -> Arrays.stream(i.split("\\W"))).collect(Collectors.toSet());
         }catch(IOException ex) {
            ex.getMessage();
        }

          return res;
    }

    public List<String> getWordListInUppercaseExcludingFirstLine(String str){
        List<String> res=new ArrayList<>();
        if(str.trim().isEmpty())
            return res;
//        try {
//            ArrayList<String> al=new ArrayList<>();
//            Files.lines(Paths.get(str)).forEach(i->al.add(i));
//            for(int i=1;i<al.size();i++)
//            {
//                String arr[]=al.get(i).split(" ");
//                for(String s:arr) {
//                    res.add(s);
//                }
//            }
//        } catch (IOException ex) {
//            ex.getMessage();
//        }

        try {
           return Files.lines(Paths.get(str)).skip(1).flatMap(i -> Arrays.stream(i.split("\\W"))).map(i->i.toUpperCase()).toList();
        }catch(IOException ex) {
            ex.getMessage();
        }

        return res;

    }

    public String getEachWordsSeparatedByColon(String str){
        if(str.trim().isEmpty())
            return null;
//        List<String> res=new ArrayList<>();
//        try {
//            ArrayList<String> al=new ArrayList<>();
//            Files.lines(Paths.get(str)).forEach(i->al.add(i));
//            for(int i=0;i<al.size();i++)
//            {
//                String arr[]=al.get(i).split(" ");
//                for(String s:arr) {
//                    res.add(s);
//                }
//            }
//        } catch (IOException ex) {
//           return null;
//        }
//        return String.join(":",res);

        try {
            return Files.lines(Paths.get(str)).flatMap(i -> Arrays.stream(i.split("\\W"))).collect(Collectors.joining(":"));
        }catch(IOException ex) {
           return null;
        }
    }

    public String getEachLineSeparatedByComma(String str){
        if(str.trim().isEmpty())
            return null;
//        ArrayList<String> al=new ArrayList<>();
//        try {
//            Files.lines(Paths.get(str)).forEach(i->al.add(i));
//        } catch (IOException ex) {
//            return null;
//        }
//        return String.join(",",al);

        try {
            return Files.lines(Paths.get(str)).collect(Collectors.joining(","));
        }catch(IOException ex) {
            return null;
        }

    }

    public Optional<Integer> getMaxOfIntegers(String str){
        if(str.trim().isEmpty())
            return Optional.empty();
//        List<String> res=new ArrayList<>();
//        int max=Integer.MIN_VALUE;
//        try {
//            ArrayList<String> al=new ArrayList<>();
//            Files.lines(Paths.get(str)).forEach(i->al.add(i));
//            for(String i:al)
//            {
//                String arr[]=i.split(" ");
//                for(String s:arr) {
//                    try {
//                        int num = Integer.parseInt(s);
//                        max = Math.max(max, num);
//                    } catch (NumberFormatException e) {
//
//                    }
//                }
//            }
//        } catch (IOException ex) {
//           return Optional.empty();
//        }
//        if(max==Integer.MIN_VALUE)
//            return Optional.empty();
//        return Optional.of(max);
        try {
            return Files.lines(Paths.get(str)).flatMap(i -> Arrays.stream(i.split("\\W")))
                    .filter(i-> {
                try {
                    Integer.parseInt(i);
                } catch (NumberFormatException ex) {
                    return false;
                }
                return true;
            }).map(i->Integer.parseInt(i)).max((a,b)->Integer.compare(a,b));
        }catch(IOException ex) {
            return Optional.empty();
        }

    }

    public Optional<Integer> getSumOfIntegers(String str){
         if(str.trim().isEmpty())
            return Optional.empty();
//        List<String> res=new ArrayList<>();
        int sum=0;
//        try {
//            ArrayList<String> al=new ArrayList<>();
//            Files.lines(Paths.get(str)).forEach(i->al.add(i));
//            for(String i:al)
//            {
//                String arr[]=i.split(" ");
//                for(String s:arr) {
//                    try {
//                        int num = Integer.parseInt(s);
//                         sum=sum+num;
//                    } catch (NumberFormatException e) {
//
//                    }
//                }
//            }
//        } catch (IOException ex) {
//            return Optional.empty();
//        }
//        if(sum==0)
//            return Optional.empty();
//        return Optional.of(sum);

        try {
           sum = Files.lines(Paths.get(str)).flatMap(i -> Arrays.stream(i.split("\\W")))
                    .filter(i-> {
                        try {
                            Integer.parseInt(i);
                        } catch (NumberFormatException ex) {
                            return false;
                        }
                        return true;
                    })
                   .map(i->Integer.parseInt(i)).reduce(0,(a,b)->a+b);
        }catch(IOException ex) {
            return Optional.empty();
        }
           if(sum==0)
              return Optional.empty();
        return Optional.of(sum);

    }

}
