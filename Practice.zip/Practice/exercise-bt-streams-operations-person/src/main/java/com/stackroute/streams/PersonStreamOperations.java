package com.stackroute.streams;

import java.util.*;
import java.util.stream.Collectors;


/**
 * This class has various methods to do stream operations on person collection
 */
public class PersonStreamOperations {

    /**
     * sorts the person list alphabetically in uppercase
     * Returns Empty Optional if the given list is null or empty
     *
     * @param personList
     * @return
     */
    public Optional<List<String>> getPersonListSortedByNameInUpperCase(List<String> personList) {

        if(personList == null || personList.isEmpty())
            return Optional.empty();

        return Optional.of(personList.stream().sorted().map(i -> i.toUpperCase()).dropWhile(i -> (i.equals(" "))||(i.isEmpty())).toList());
    }

    /**
     * Sorts the distinct person names in descending order
     * Returns empty set if the given list is empty or null
     *
     * @param personList
     * @return
     */

    public Set<String> getDistinctPersonNamesSortedInDescendingOrder(List<String> personList) {

        Set<String> s=new HashSet<>();
        if(personList == null || personList.isEmpty())
            return s;

      // return  personList.stream().distinct().sorted((a,b)->b.compareTo(a)).collect(Collectors.toSet());
        List<String> al=personList.stream().filter(i->!i.trim().isEmpty()).distinct().sorted((a,b)->b.compareTo(a)).toList();
        System.out.println(al);
        return new LinkedHashSet<>(al);
    }

    /**
     * Returns "Person found" if the person searched is available in the list or else returns "Person not found"
     * Returns "Give proper input not null" if the given list or name to search is null
     *
     * @param personList
     * @return
     */
    public String searchPerson(List<String> personList, String nameToSearch) {
        if(personList==null||nameToSearch==null)
            return "Give proper input not null";
        if(personList.stream().anyMatch(i->i.equalsIgnoreCase(nameToSearch)))
             return "Person found";
        return "Person not found";
    }

    /**
     * Filters the list whose name length is greater than five and sorts by name length
     * Returns empty list if the given list is empty or null
     *
     * @param personList
     * @return
     */

    public List<String> getPersonListSortedByLengthWithNameLengthGreaterThanFive(List<String> personList) {
        if(personList == null || personList.isEmpty())
            return new ArrayList<>();
        return personList.stream().filter(i->i.length()>5).sorted((a,b)->a.length()-b.length()).toList();
    }

    /**
     * Returns the person name having maximum age from the given Map<String,Integer> having name as key and age as value
     * Returns "Give proper input not null" if the given map is empty or null
     *
     * @param personMap
     * @return
     */

    public String getPersonByMaxAge(Map<String, Integer> personMap) {
        if(personMap == null || personMap.isEmpty())
            return "Give proper input not null";
       // int max=personMap.values().stream().max(Integer::compareTo).get();
        int max=personMap.values().stream().max((a,b)->Integer.compare(a,b)).get();
        Set<String> s=personMap.entrySet().stream().filter(a->a.getValue()>=max).map(i->i.getKey()).collect(Collectors.toSet());
        return String.join(" ",s);
    }

}
