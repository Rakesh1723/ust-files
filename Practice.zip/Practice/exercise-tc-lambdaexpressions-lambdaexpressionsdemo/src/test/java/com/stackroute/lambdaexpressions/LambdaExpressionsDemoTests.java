package com.stackroute.lambdaexpressions;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LambdaExpressionsDemoTests {

    private LambdaExpressionsDemo led;

    @BeforeEach
    public void setUp() {
        led=new LambdaExpressionsDemo();
    }

    @AfterEach
    public void tearDown() {
        led = null;
    }

    @Test
    public void testArithmeticOperation(){
           Assertions.assertEquals(new ArrayList<>(List.of(10,4,2)),led.arithmeticOperation(new ArrayList<>(List.of(2,5,10)),20));
    }

    @Test
    public void testArithmeticOperationWithException(){
        Assertions.assertThrows(RuntimeException.class,()->led.arithmeticOperation(new ArrayList<>(List.of(2,0,10)),20));
        }

    @Test
    public void testArithmeticOperationWithEmptyList(){
        Assertions.assertDoesNotThrow(()->led.arithmeticOperation(new ArrayList<>(),7));
    }

    @Test
    public void testArithmeticOperationWithNullValues(){
        Assertions.assertThrows(NullPointerException.class,()->led.arithmeticOperation(new ArrayList<>(List.of(2,0,10)),null));
        Assertions.assertThrows(NullPointerException.class,()->led.arithmeticOperation(null,9));
        Assertions.assertThrows(NullPointerException.class,()->led.arithmeticOperation(null,null));
    }

    @Test
    public void testWriteToFile(){
        Assertions.assertEquals(new ArrayList<>(List.of("file1.txt","file2.txt","file3.txt")),led.writeToFile(0,new ArrayList<>(List.of("sai","ram","ramesh"))));

    }

    @Test
    public void testWriteToFileWithException(){
        Assertions.assertThrows(RuntimeException.class,()->led.writeToFile(10,new ArrayList<>(List.of("sai","ram","ramesh"))));
    }

    @Test
    public void testWriteToFileWithEmptyList(){
        Assertions.assertDoesNotThrow(()->led.writeToFile(4,new ArrayList<>()));

    }

    @Test
    public void testWriteToFileWithNullValues(){
         Assertions.assertThrows(NullPointerException.class,()->led.writeToFile(4,null));

    }

}
