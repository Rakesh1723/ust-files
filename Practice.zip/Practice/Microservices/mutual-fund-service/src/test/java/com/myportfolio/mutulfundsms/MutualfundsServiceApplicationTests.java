package com.myportfolio.mutulfundsms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MutualfundsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
