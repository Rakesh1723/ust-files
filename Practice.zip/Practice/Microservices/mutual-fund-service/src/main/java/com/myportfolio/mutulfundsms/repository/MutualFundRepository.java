package com.myportfolio.mutulfundsms.repository;

import com.myportfolio.mutulfundsms.model.MutualFunds;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MutualFundRepository extends JpaRepository<MutualFunds,Integer> {
}
