package com.myportfolio.stockms.dto;

import java.util.List;

public record StockInputList(List<Integer> ids) {
}
