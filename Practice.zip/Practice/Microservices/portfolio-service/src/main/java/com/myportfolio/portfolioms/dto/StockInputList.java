package com.myportfolio.portfolioms.dto;

import java.util.List;

public record StockInputList(List<Integer> ids) {
}
