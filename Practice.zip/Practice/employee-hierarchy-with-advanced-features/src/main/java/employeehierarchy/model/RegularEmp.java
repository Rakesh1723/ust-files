package employeehierarchy.model;

public non-sealed class RegularEmp extends Employee{
    public RegularEmp(long id, String name, String position, double salary) {
        super(id, name, position, salary);
    }
}
