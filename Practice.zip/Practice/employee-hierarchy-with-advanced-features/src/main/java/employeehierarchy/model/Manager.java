package employeehierarchy.model;

public non-sealed class Manager extends Employee{

    public Manager(long id, String name, String position, double salary) {
        super(id, name, position, salary);
    }
}
