package employeehierarchy.model;

public non-sealed class Developer extends Employee{

    public Developer(long id, String name, String position, double salary) {
        super(id, name, position, salary);
    }
}
