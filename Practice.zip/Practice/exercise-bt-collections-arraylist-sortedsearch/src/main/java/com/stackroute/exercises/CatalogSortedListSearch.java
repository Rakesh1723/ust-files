package com.stackroute.exercises;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CatalogSortedListSearch {

     static List<String> al;

    //write here logic to get sorted Array List which is a global class variable
    public String catalogListSorter(List<String> unSortedCatalogList) {
        al = unSortedCatalogList;
        if (al == null)
            return "The catalog list is null";
        if (unSortedCatalogList.isEmpty())
            return "The catalog List is empty";
        for(String s:al){
           if (s == null || s.isEmpty() || s ==" ")
               return "The catalog List contains empty or null or blank space as a value";
    }
        Collections.sort(al);
        return String.valueOf(al);
    }

    //write here logic to search the input value in sorted Array List
    public String catalogListSearcher(String value) {
        if(value==null || value.isEmpty() || value == ""||value ==" ")
            return "Input is not accepted";
        for(String s:al)
        {  if(s.equalsIgnoreCase(value)) {
            System.out.println("Found: "+value);
            return "Found: "+s;
        }
        }
        return  "Not Found";
    }
}

