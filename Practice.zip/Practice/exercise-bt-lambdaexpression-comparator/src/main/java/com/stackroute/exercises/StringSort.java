package com.stackroute.exercises;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StringSort {

    //write here logic to sort a string List
    public String stringSorter(List<String> stringList, String sortingOrder) {

        if(stringList == null || stringList.isEmpty() || sortingOrder == null || sortingOrder.isEmpty()|| sortingOrder.equals(" "))
            return "Given stringList or sortingOrder is empty, null or blank space";

        if(stringList.contains(" ")|| stringList.contains(""))  // stringList.stream().anyMatch(s -> s.equals(" ") || s.isEmpty()))
            return "The list contains an empty or blank space value";

        if(stringList.size()==1)
            return "The list contains only one value";

        if(! (sortingOrder.equalsIgnoreCase("desc") ||  sortingOrder.equalsIgnoreCase("asc")) )
            return "No sorting order present for given string '"+sortingOrder+"' , 'asc' for ascending order sort and 'desc' for descending order sort";

        if(sortingOrder.equalsIgnoreCase("asc"))
            Collections.sort(stringList);
        else
            stringList.sort(Comparator.reverseOrder());

        return "["+String.join(", ",stringList)+"]";
    }
}
