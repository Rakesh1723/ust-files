package com.stackroute.lambdaexpression;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ProductSorter {

    ArrayList<Product> al=new ArrayList<Product>();

    public List<Product> getProductList(){
         return al;
    }
    public List<Product> sortProductByNameLength(){
        return al.stream().sorted((a,b)->a.getName().compareTo(b.getName())).sorted((a,b)->Integer.compare(a.getName().length(),b.getName().length())).toList();
    }
    public List<Product> sortProductByName(){
        return al.stream().sorted((a,b)->a.getName().compareTo(b.getName())).toList();
    }
    public List<Product> sortProductByPriceDescending(){
        return  al.stream().sorted((a,b)->Double.compare(b.getPrice(),a.getPrice())).toList();
    }
    public List<Product> sortProductByCategoryAscendingAndByPriceDescending(){
        return al.stream().sorted((a,b)->Double.compare(b.getPrice(),a.getPrice())).sorted((a,b)->a.getCategory().compareTo(b.getCategory())).toList();
    }
}
