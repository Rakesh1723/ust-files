package com.stackroute.collections;

import java.time.LocalDate;
import java.util.*;

/*
This class contains a property called movieMap of type Map
This class contains methods for adding key-value pairs of Movie and its rating to HashMap and
various methods for accessing the keys and values based on some conditions
 */
public class MovieService {

    /**
     * Constructor to create movieMap as an empty  LinkedHashMap object
     */
    public  Map<Movie, Integer> movieMap;

    public MovieService() {
         movieMap=new LinkedHashMap<>();
    }

    /*
    Returns the movieMap object
     */
    public Map<Movie, Integer> getMovieMap() {
        return movieMap;
    }

    /*
    Add key-value pairs of Movie-Integer type and returns Set of Map.Entry
     */
    public Set<Map.Entry<Movie, Integer>> addKeyValuePairsToMap(Movie movie, Integer rating) {
        movieMap.put(movie,rating);
      return new HashSet<>(movieMap.entrySet());
    }

    /*
    Return Set of movie names having rating greater than or equal to given rating
     */
    public List<String> getHigherRatedMovieNames(int rating) {

         List<String> al=new ArrayList<>();
        for(Map.Entry<Movie, Integer> m: movieMap.entrySet())
        {  if(m.getValue()>=rating)
              al.add(m.getKey().getMovieName()) ;
        }
        return al;
    }

    /*
    Return Set of movie names belonging to specific genre
     */
    public List<String> getMovieNamesOfSpecificGenre(String genre) {
        List<String> al=new ArrayList<>();
        for(Movie i:movieMap.keySet())
        {   if(i.getGenre().equals(genre))
            al.add(i.getMovieName());
        }
        return al;
    }

   /*
   Return Set of movie names which are released after Specific releaseDate and having rating less than or equal to 3
    */

    public List<String> getMovieNamesReleasedAfterSpecificDateAndRatingLesserThanThree(LocalDate releaseDate) {
        List<String> al=new ArrayList<>();
        for(Map.Entry<Movie, Integer> m: movieMap.entrySet())
        {  if(m.getValue()<=3 && m.getKey().getReleaseDate().isAfter(releaseDate))
            al.add(m.getKey().getMovieName()) ;
        }
        return al;
    }

    /*
    Return set of movies sorted by release dates in ascending order.
    Hint: Use TreeMap
     */
    public List<Movie> getSortedMovieListByReleaseDate() {
        List<Movie> al=new ArrayList<>();
        TreeMap<LocalDate,Movie> mp=new TreeMap<>();
        for(Map.Entry<Movie, Integer> m: movieMap.entrySet())
        {  mp.put(m.getKey().getReleaseDate(),m.getKey());
        }
        for(Map.Entry<LocalDate,Movie> m: mp.entrySet())
        {
            al.add(m.getValue());
        }
        return al;
    }

    /*
   Return set of movies sorted by rating.
   Hint: Use Comparator and LinkedHashMap
    */
    public Map<Movie, Integer> getSortedMovieListByRating() {
        Map<Movie,Integer> mp=new LinkedHashMap<>();
        List<Map.Entry<Movie, Integer>> al = new ArrayList<>(movieMap.entrySet());

        Collections.sort(al,Comparator.comparingInt(Map.Entry::getValue));  //(a,b)->Integer.compare(a.getValue(),b.getValue()));
        for(Map.Entry<Movie, Integer> m:al)
        {  mp.put(m.getKey(),m.getValue());
        }
        return mp;
    }
}
