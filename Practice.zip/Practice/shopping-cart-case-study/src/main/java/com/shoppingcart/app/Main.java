package com.shoppingcart.app;


public class Main {
    public static void main(String[] args) {

    }
}