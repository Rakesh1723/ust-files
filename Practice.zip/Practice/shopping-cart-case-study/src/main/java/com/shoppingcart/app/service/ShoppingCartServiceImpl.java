package com.shoppingcart.app.service;

import com.shoppingcart.app.exception.InvalidProductException;
import com.shoppingcart.app.exception.InvalidQuantityException;
import com.shoppingcart.app.exception.ProductNotFoundException;
import com.shoppingcart.app.model.Product;
import com.shoppingcart.app.repository.ShoppingCartRepository;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

public class ShoppingCartServiceImpl implements ShoppingCartService {

    private ShoppingCartRepository shoppingCartRepository;

//    public ShoppingCartServiceImpl(ShoppingCartRepository shoppingCartRepositoryImpl) {
//        this.shoppingCartRepository = shoppingCartRepositoryImpl;
//    }

    // Validate the following conditions and throw appropriate exceptions if the conditions are not met:

    // 1. Product :
    //    - Product id should be greater than 0
    //    - Product name should not be null or empty and should contain alphanumeric characters only
    //    - Product category should not be null or empty and should contain alphabets only
    //    - Product price should be greater than 0
    //    - Product quantity should be greater than 0
    // 2. Quantity :
    //    - Quantity should be greater than 0

    public void addProduct(Product product, int quantity) throws InvalidQuantityException, InvalidProductException {
        if(product.getId() <= 0 || product.getName()==null || product.getName().trim().isEmpty() || ! Pattern.matches("[a-zA-Z0-9]+",product.getName())
                || product.getCategory()==null||product.getCategory().trim().isEmpty()|| ! Pattern.matches("[a-zA-Z0-9]+",product.getCategory())
               || product.getPrice()<=0 || product.getQuantity()<=0) {
            throw new InvalidProductException("Invalid product exception");
        }
        if(quantity <= 0) {
            throw new InvalidQuantityException("Invalid quantity exception");
        }
         shoppingCartRepository.addProduct(product,quantity);

    }

    public void removeProduct(Product product) throws ProductNotFoundException {

//        if(!shoppingCartRepository.getProducts().stream().anyMatch(i->i==product))
//             throw new ProductNotFoundException("Product not found exception");
        shoppingCartRepository.removeProduct(product);
    }

    public void updateProductQuantity(Product product, int quantity) throws ProductNotFoundException, InvalidQuantityException {

//        if(!shoppingCartRepository.getProducts().stream().anyMatch(i->i==product))
//            throw new ProductNotFoundException("Product not found exception");
        if(quantity <=0)
            throw new InvalidQuantityException("Invalid quantity exception");
        shoppingCartRepository.updateProductQuantity(product,quantity);

    }

    public double calculateTotalPrice() {
        return shoppingCartRepository.calculateTotalPrice();
    }

    public List<Product> filterProductsByCategory(String category) {
        return shoppingCartRepository.filterProductsByCategory(category);
    }

    public List<Product> filterProductsByPriceRange(double minPrice, double maxPrice) {
        return shoppingCartRepository.filterProductsByPriceRange(minPrice, maxPrice);
    }

    public void displayCartItems() {
         shoppingCartRepository.displayCartItems();
    }

    public Product findMostExpensiveProduct() {
        return shoppingCartRepository.findMostExpensiveProduct().get();
    }

    public List<Product> sortProductsByName() {
        return  shoppingCartRepository.sortProductsByName();
    }

    public double calculateDiscountedTotal(double discountPercentage) {
        return  shoppingCartRepository.calculateDiscountedTotal(discountPercentage);
    }

    public List<Product> getProducts() {
        return shoppingCartRepository.getProducts();
    }
}
