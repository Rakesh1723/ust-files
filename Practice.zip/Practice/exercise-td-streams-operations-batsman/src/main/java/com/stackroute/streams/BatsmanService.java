package com.stackroute.streams;

import java.util.*;
import java.util.stream.Collectors;

public class BatsmanService {

  public Optional<Batsman> getBatsman(List<Batsman> batsmanList, String batsmanName, String countryCode) {

      if (batsmanList == null || batsmanName == null || countryCode == null)
          return Optional.empty();

      if (!batsmanList.stream().anyMatch(
              i -> i.getName().equalsIgnoreCase(batsmanName)))
          return Optional.empty();

      return Optional.of(batsmanList.stream().filter(i -> i.getName().equalsIgnoreCase(batsmanName) && i.getCountry().getCountryCode().equalsIgnoreCase(countryCode)).findFirst().orElseThrow(() -> new CountryNotFoundException()));

  }

  public String getBatsmanNamesForCountry(List<Batsman> batsmanList, String countryCode){
      if (batsmanList == null || batsmanList.isEmpty() || countryCode == null)
          return null;
      return "["+String.join(",",batsmanList.stream().filter(i->i.getCountry().getCountryCode().equalsIgnoreCase(countryCode)).map(i->i.getName()).sorted().toList())+"]";
  }

 public Map<String,Integer> getPlayerNameWithTotalRuns(List<Batsman> batsmanList){

     if (batsmanList == null || batsmanList.isEmpty())
         return new HashMap<String, Integer>();

    return batsmanList.stream().filter(i->i.getMatchesPlayed()>50).collect(Collectors.toMap(i->i.getName(),i->i.getTotalRuns()));

 }

  public int getHighestRunsScoredByBatsman(List<Batsman> batsmanList, String countryName){

      if (batsmanList == null || batsmanList.isEmpty())
        return 0;
    //  return batsmanList.stream().filter(i->i.getCountry().getName().equalsIgnoreCase(countryName)).map(i->i.getHighestScore()).max((a,b)->a-b).get();
     return (int) batsmanList.stream().filter(i->i.getCountry().getName().equalsIgnoreCase(countryName)).mapToDouble(i->i.getHighestScore()).max().getAsDouble();
     //return (int)a.getAsDouble();

  }

  public Optional<LinkedList<String>> getPlayerNamesByCountry(List<Batsman> batsmanList, String countryName){

      if (batsmanList == null || batsmanList.isEmpty() || countryName == null)
          return Optional.empty();

     var al= batsmanList.stream().filter(i->i.getCountry().getName().equalsIgnoreCase(countryName) && i.getTotalRuns()>5000).sorted((a, b)->Integer.compare(a.getTotalRuns(),b.getTotalRuns())).map(a->a.getName()).toList();

     if(al.isEmpty())
         return Optional.empty();

     return Optional.of(new LinkedList<String>(al));

  }
}
