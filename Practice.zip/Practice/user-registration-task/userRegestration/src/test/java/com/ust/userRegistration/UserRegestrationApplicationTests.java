package com.ust.userRegistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRegestrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
