package com.ust.userRegistration.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="User_db")
public class User {
    @Id
    private int id;
    private String name;
    private String location;
    private String mobileNo;
}
