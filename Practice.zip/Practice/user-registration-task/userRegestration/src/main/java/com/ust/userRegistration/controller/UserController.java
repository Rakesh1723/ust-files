package com.ust.userRegistration.controller;

import com.ust.userRegistration.model.User;
import com.ust.userRegistration.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = {"http://127.0.0.1:5500"})
@RestController
@RequestMapping("/api/v4/User")
public class UserController {

    @Autowired
    private UserRepository userRepo;

    @PostMapping
    public User saveUser(@RequestBody User user)
    {
        return userRepo.save(user);
    }

    @GetMapping("/{id}")
    public User getUser(@PathVariable int id)
    {
        return userRepo.findById(id).orElseThrow(()->new RuntimeException("user not found"));
    }

    @GetMapping
    public List<User> getAllUsers(){
        return userRepo.findAll();
    }

}
