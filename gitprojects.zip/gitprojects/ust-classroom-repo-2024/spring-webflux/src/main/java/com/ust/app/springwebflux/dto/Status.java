package com.ust.app.springwebflux.dto;

public enum Status {
    PENDING, COMPLETED
}
