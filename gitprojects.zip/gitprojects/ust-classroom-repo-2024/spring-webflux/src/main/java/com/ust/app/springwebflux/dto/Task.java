package com.ust.app.springwebflux.dto;

public record Task(int id, String title, Status status) {
}

