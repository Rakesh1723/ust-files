package com.ust.app.springwebflux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebfluxApplicationTests {

    @Test
    void contextLoads() {
    }

}
