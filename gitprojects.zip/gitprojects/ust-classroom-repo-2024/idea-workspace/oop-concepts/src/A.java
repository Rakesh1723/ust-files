public class A
{
    public static void main(String args[])
    {
        //\u000d System.out.println("hello");
    }
}

