package interfaceexamples;

public interface Scannable {
    void scan();
}
