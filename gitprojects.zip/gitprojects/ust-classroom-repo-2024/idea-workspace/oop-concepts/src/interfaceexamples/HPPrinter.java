package interfaceexamples;

public class HPPrinter implements Printable {

    @Override
    public void print() {
        System.out.println("Hello From HP");
    }
}
