package loosecouplingexample;

public interface Sim {
    void call();
    void browseInternet();
}
