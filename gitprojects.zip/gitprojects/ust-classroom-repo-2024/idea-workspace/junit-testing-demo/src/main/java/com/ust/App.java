package com.ust;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        Calculator calc = new Calculator();

//        int a = Integer.parseInt(args[0]);
//        int b = Integer.parseInt(args[1]);

        int result = calc.divide(5,0);
//
        System.out.println(result);



    }
}
