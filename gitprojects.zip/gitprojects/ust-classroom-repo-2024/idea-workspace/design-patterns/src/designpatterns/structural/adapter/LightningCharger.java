package designpatterns.structural.adapter;

public interface LightningCharger {
    void chargeWithLightning();
}
