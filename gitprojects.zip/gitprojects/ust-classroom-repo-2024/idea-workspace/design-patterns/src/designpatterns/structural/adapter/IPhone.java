package designpatterns.structural.adapter;

public class IPhone {

    public void charge(){
        System.out.println("Charging with Lightning Charger");
    }

}
