package designpatterns.structural.adapter;

public class AndroidPhone {

    public void charge(){
        System.out.println("Charging with Type-C Charger");
    }

}
