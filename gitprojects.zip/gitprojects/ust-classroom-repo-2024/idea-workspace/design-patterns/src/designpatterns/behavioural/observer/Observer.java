package designpatterns.behavioural.observer;

public interface Observer {

    void update(String videoTitle);

}
