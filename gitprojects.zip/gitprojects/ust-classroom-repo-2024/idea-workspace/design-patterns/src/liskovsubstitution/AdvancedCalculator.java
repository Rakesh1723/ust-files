package liskovsubstitution;

public class AdvancedCalculator extends Calculator {




}
