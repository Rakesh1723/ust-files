package sealedclasses;

public final class Developer extends Employee{
}
