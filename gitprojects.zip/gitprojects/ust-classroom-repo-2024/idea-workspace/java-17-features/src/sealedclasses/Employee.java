package sealedclasses;

public sealed class Employee permits Developer, Manager {
}
