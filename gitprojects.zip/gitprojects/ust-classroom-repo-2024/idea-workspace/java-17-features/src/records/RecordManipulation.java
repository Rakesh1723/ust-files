package records;

import java.time.LocalDate;

public class RecordManipulation {

    public static void main(String[] args) {

        Trainee t1 = new Trainee(1,"Charan");

        System.out.println(t1);

        t1.name();

    }

}
