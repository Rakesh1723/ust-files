package com.ust.webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
