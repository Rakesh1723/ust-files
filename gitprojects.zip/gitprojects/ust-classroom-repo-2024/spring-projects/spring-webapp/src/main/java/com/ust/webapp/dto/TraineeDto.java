package com.ust.webapp.dto;

public record TraineeDto(int id, String name, String location) {
}