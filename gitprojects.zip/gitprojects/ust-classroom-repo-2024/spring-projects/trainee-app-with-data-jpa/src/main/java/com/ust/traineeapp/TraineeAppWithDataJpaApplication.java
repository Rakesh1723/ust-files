package com.ust.traineeapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TraineeAppWithDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraineeAppWithDataJpaApplication.class, args);
	}

}
