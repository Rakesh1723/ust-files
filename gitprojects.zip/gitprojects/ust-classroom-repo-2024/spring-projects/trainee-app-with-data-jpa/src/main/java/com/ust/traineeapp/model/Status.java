package com.ust.traineeapp.model;

public enum Status {

    NOT_STARTED,ONGOING,COMPLETED;

}
