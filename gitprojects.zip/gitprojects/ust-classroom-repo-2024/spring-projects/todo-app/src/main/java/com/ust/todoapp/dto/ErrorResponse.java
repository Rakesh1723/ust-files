package com.ust.todoapp.dto;

public record ErrorResponse(int status, String message) {
}
