package com.ust.todoapp.model;

public enum Status {
    PENDING,
    COMPLETED
}
