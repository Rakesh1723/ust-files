package com.ust.traineeapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraineeAppWithMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
