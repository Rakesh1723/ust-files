package com.ust.traineeapp.service;

import com.ust.traineeapp.model.Trainee;

import java.math.BigInteger;
import java.util.List;

public interface TraineeService {

    Trainee saveTrainee(Trainee trainee);

//    Trainee findTraineeById(BigInteger id);
//
//    void removeTrainee(BigInteger id);
//
//    List<Trainee> getAllTrainees();
//
//    Trainee updateTrainee(BigInteger id, Trainee trainee);


}
