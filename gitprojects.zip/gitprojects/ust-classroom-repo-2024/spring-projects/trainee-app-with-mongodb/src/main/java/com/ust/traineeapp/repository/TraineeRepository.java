package com.ust.traineeapp.repository;

import com.ust.traineeapp.model.Trainee;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.math.BigInteger;

//public interface TraineeRepository extends MongoRepository<Trainee, BigInteger> {
//}
