function greet(name){
    console.log("Good Morning "+name);   
}

setTimeout(()=>greet('Karan'),5000)
console.log('Have a nice day')

// function display(name,callback){
//     callback(name)
// }

// display('Gaurav',greet)


