var trainee = {
    id: 1,
    name: 'Gaurav',
    show: function () {
        console.log(this.id);
        console.log(this.name);
    }
};
trainee.show();
