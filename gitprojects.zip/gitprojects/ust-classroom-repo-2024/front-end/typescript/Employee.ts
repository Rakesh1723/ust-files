
import {Person} from "./Person";

class Employee extends Person{
    
}