export class Person{

   constructor(public name:string,public email:string,public age:number){ }

   
}

// let p:Person = new Person('Karan','karan@yahoo.com',25);

// p.print();

let p:Person ={
    name:'Javed',
    email:'javed@yahoo.com',
    age:27
}

