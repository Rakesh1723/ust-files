package com.app.employeehierarchy.model;

public non-sealed class Executive extends Employee {
}
