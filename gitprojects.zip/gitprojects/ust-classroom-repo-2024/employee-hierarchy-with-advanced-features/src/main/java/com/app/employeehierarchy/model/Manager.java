package com.app.employeehierarchy.model;

public non-sealed class Manager extends Employee {

    public void play(){

    }

}
