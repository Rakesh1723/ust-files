package com.app.employeehierarchy.model;

public non-sealed class Developer extends Employee {
        // TODO: Override toString method to display developer information
}

