package com.myportfolio.mutualfundsms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MutualFundServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MutualFundServiceApplication.class, args);
	}

}
