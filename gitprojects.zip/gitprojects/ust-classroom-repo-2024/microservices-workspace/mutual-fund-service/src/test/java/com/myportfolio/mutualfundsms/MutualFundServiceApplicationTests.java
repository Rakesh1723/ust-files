package com.myportfolio.mutualfundsms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MutualFundServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
