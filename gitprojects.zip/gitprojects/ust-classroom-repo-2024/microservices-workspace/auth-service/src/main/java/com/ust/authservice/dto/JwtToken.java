package com.ust.authservice.dto;

public record JwtToken(String jwt) {
}
