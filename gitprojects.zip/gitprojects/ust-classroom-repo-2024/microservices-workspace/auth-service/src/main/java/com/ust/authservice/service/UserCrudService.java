package com.ust.authservice.service;

import com.ust.authservice.model.UserModel;

public interface UserCrudService {

    public UserModel saveUser(UserModel user);

}
