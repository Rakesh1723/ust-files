package com.ust.authservice.dto;

public record UserCredentials(String username, String password) {
}
