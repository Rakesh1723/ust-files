package com.ust.authservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthServiceWithSpringBoot2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
