package com.myportfolio.stocksms.dto;

import java.util.List;

public record StockInputList(List<Integer> ids) {
}
