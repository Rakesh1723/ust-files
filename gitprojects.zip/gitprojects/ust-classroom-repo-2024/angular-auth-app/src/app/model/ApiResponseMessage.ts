export interface ApiResponseMessage{
    message:string
}