export interface UserCredentials{
    username:string;
    password:string;
}