export interface JwtToken{
    jwt:string
}