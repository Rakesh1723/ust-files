package com.bookstoreapp;




public class BookstoreAppApplication {

	public static void main(String[] args) {

	}

}
